class AutomatonException(Exception):
    def __init__(self, message: str):
        print(message)
